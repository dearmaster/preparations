package com.master;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Test {

    public static void main(String[] args) {

        combineMeritModelQuery();
    }

    public static void test() {
        Connection conn1 = getMeritConnection();
        Connection conn2 = getModelConnection();
        Connection conn3 = getMeritConnection();
        System.out.println("conn1: " + conn1 + "\n" +
                "conn2: " + conn2 + "\n" +
                "conn3: " + conn3);

        close(conn1);
        close(conn2);
        close(conn3);
    }

    private static void close(Connection conn) {
        if(conn != null) {
            try {
                conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    public static Connection getMeritConnection() {

        String username = "cpnsrvr";
        String password = "cpnsrvr";
        String url = "jdbc:sybase:Tds:merdb3u.nam.nsroot.net:5500/CPN_Margins";

        Connection conn = null;

        try {
            DriverManager.registerDriver(new com.sybase.jdbc2.jdbc.SybDriver());
//            Class.forName("com.sybase.jdbc2.jdbc.SybDriver");
            java.util.Properties info = new java.util.Properties();
            info.put("user", username);
            info.put("password", password);
            info.put("ENCRYPT_PASSWORD", "TRUE");
            info.put("JCE_PROVIDER_CLASS", "org.bouncycastle.jce.provider.BouncyCastleProvider");
            conn = DriverManager.getConnection(url, info);
        } catch (SQLException e) {
            e.printStackTrace();
        }
//        System.out.println("Retrieved merit connection: " + conn);
        return conn;
    }

    public static Connection getModelConnection() {

        String username = "fidcpm";
        String password = "fidcpm123";
        String url = "jdbc:sybase:Tds:xpmdb14u.nam.nsroot.net:5000/rsk_cpm";

        Connection conn = null;

        try {
            DriverManager.registerDriver(new com.sybase.jdbc4.jdbc.SybDriver());
            java.util.Properties info = new java.util.Properties();
            info.put("user", username);
            info.put("password", password);
            info.put("ENCRYPT_PASSWORD", "TRUE");
            info.put("JCE_PROVIDER_CLASS", "org.bouncycastle.jce.provider.BouncyCastleProvider");
            conn = DriverManager.getConnection(url, info);
        } catch (SQLException e) {
            e.printStackTrace();
        }
//        System.out.println("Retrieved model connection: " + conn);
        return conn;
    }

    public static void combineMeritModelQuery() {
        String username = "cpnsrvr";
        String password = "cpnsrvr";
        String url = "jdbc:sybase:Tds:merdb3u.nam.nsroot.net:5500/CPN_Margins";

        Connection connMerit1 = null;
        Connection connMerit2 = null;
        java.util.Properties info = new java.util.Properties();

        try {
//            DriverManager.registerDriver(new com.sybase.jdbc2.jdbc.SybDriver());
            Class.forName("com.sybase.jdbc2.jdbc.SybDriver");
            info.put("user", username);
            info.put("password", password);
            info.put("ENCRYPT_PASSWORD", "TRUE");
            info.put("JCE_PROVIDER_CLASS", "org.bouncycastle.jce.provider.BouncyCastleProvider");
            connMerit1 = DriverManager.getConnection(url, info);
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }


        username = "fidcpm";
        password = "fidcpm123";
        url = "jdbc:sybase:Tds:xpmdb14u.nam.nsroot.net:5000/rsk_cpm";

        Connection connModel = null;

        try {
            DriverManager.registerDriver(new com.sybase.jdbc4.jdbc.SybDriver());
            info = new java.util.Properties();
            info.put("user", username);
            info.put("password", password);
            info.put("ENCRYPT_PASSWORD", "TRUE");
            info.put("JCE_PROVIDER_CLASS", "org.bouncycastle.jce.provider.BouncyCastleProvider");
            connModel = DriverManager.getConnection(url, info);
        } catch (SQLException e) {
            e.printStackTrace();
        }


        try {
            connMerit2 = DriverManager.getConnection(url, info);
        } catch (SQLException e) {
            e.printStackTrace();
        }

        System.out.println("conn1: " + connMerit1 + "\n" +
                "conn2: " + connModel + "\n" +
                "conn3: " + connMerit2);

        close(connMerit1);
        close(connModel);
        close(connMerit2);
    }

}