package com.master.sort.insertsort;

import com.master.sort.AbstractSort;

public class InsertSort extends AbstractSort {

    @Override
    protected void sort(int[] array) {
        int tmp, j;
        for(int i=1; i<array.length; i++) {
            tmp = array[i];
            for(j=i; j>0 && array[j-1] > tmp; j--) {
                array[j] = array[j-1];
            }
            array[j] = tmp;
        }
    }

    public static void main(String[] args) {
        new InsertSort().process();
    }

}