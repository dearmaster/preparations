package com.master.sort.quicksort;

import com.master.sort.AbstractSort;

public class QuickSort extends AbstractSort {

    public void sort(int[] array, int start, int end) {
        int low = start;
        int high = end;
        int base = array[high];
        while(low < high) {
            while(low < high && array[low] <= base) {
                low++;
            }
            if(low < high) {
                int tmp = array[low];
                array[low] = array[high];
                array[high] = tmp;
                high--;
            }
            while(low < high && array[high] >= base) {
                high--;
            }
            if(low < high) {
                int tmp = array[low];
                array[low] = array[high];
                array[high] = tmp;
                low++;
            }
        }
        if(low > start) {
            sort(array, start, low-1);
        }
        if(low < end) {
            sort(array, low + 1, end);
        }
    }

    @Override
    protected void sort(int[] array) {
        sort(array, 0, array.length-1);
    }

    private static final QuickSort instance = new QuickSort();

    public static QuickSort getInstance() {
        return instance;
    }

    public static void main(String[] args) {
        new QuickSort().process();
    }

}