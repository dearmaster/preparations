package com.master.sort;

import com.master.sort.bubblesort.BubbleSort;
import com.master.sort.mergesort.MergeSort;
import com.master.sort.quicksort.QuickSort;
import com.master.sort.selectionsort.SelectionSort;

public class StartProcessAllSort {

    public static void main(String[] args) {
        MergeSort mergeSort = MergeSort.getInstance();
        BubbleSort bubbleSort = BubbleSort.getInstance();
        QuickSort quickSort = QuickSort.getInstance();
        SelectionSort selectionSort = SelectionSort.getInstance();
        mergeSort.process();
        quickSort.process();
        bubbleSort.process();
        selectionSort.process();
    }

}