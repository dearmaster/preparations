package com.master.sort.selectionsort;

import com.master.sort.AbstractSort;

public class SelectionSort extends AbstractSort {

    @Override
    protected void sort(int[] array) {
        for(int i=0; i<array.length; i++) {
            for(int j=i+1; j<array.length; j++) {
                if(array[j] < array[i]) {
                    int tmp = array[j];
                    array[j] = array[i];
                    array[i] = tmp;
                }
            }
        }
    }

    public static void main(String[] args) {
        new SelectionSort().process();
    }

    private final static SelectionSort instance = new SelectionSort();

    public static SelectionSort getInstance() {
        return instance;
    }

}