package com.master.sort;

public interface Action {
    void doInAction();
}