package com.master.sort;

import java.util.Arrays;

public abstract class AbstractSort {

    private static final int LENGTH = 100000;
    private static int[] sharedArray;
    private static int[] array;
    private static final Object LOCK = new Object();

    public static int[] mockUpData(int length) {
        int[] array = new int[length];
        for(int i=0; i<length; i++) {
            array[i] = (int) (Math.random()*length);
        }
        return array;
    }

    public void print(int[] array) {
        for(int i=0; i<array.length; i++) {
            System.out.print(array[i] + " ");
        }
        System.out.println();
    }

    public void executeAndLogTimeUsed(Action action) {
        long startTime = System.currentTimeMillis();
        action.doInAction();
        long endTime = System.currentTimeMillis();
        StackTraceElement[] stacks = (new Throwable()).getStackTrace();
        StackTraceElement caller = stacks[1];
        System.out.println(this.getClass().getSimpleName() + " - Time cost for [" + caller.getClassName() + "." + caller.getMethodName() + "] cost " + (endTime - startTime) + " milliseconds.");
    }

    public void subMockUpData() {
        executeAndLogTimeUsed(new Action() {
            @Override
            public void doInAction() {
                sharedArray = mockUpData(LENGTH);
            }
        });
    }

    public void subSort() {
        executeAndLogTimeUsed(new Action() {
            @Override
            public void doInAction() {
                sort(array);
            }
        });
    }

    public void process() {
        if(sharedArray == null) {
            synchronized (LOCK) {
                if(sharedArray == null) {
                    subMockUpData();
                }
            }
        }
        array = Arrays.copyOf(sharedArray, sharedArray.length);
        System.out.println("the data mocked up is:");
        print(array);

        subSort();
        System.out.println("after sort: ");
        print(array);
    }

    protected abstract void sort(int[] array);


}