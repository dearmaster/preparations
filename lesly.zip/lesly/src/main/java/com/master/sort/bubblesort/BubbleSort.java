package com.master.sort.bubblesort;

import com.master.sort.AbstractSort;

public class BubbleSort extends AbstractSort {

    @Override
    public void sort(int[] array) {
        for(int i=array.length-1; i>=1; i--) {
            for(int j=0; j<i; j++) {
                if(array[j]>array[j+1]) {
                    int temp = array[j];
                    array[j] = array[j+1];
                    array[j+1] = temp;
                }
            }
        }
    }

    public static void main(String[] args) {
        new BubbleSort().process();
    }

    private static BubbleSort instance;

    public static BubbleSort getInstance() {
        if(instance == null) {
            synchronized (BubbleSort.class) {
                if (instance == null) {
                    instance = new BubbleSort();
                }
            }
        }
        return instance;
    }

}